const userService = require('../services/user.service')


module.exports = {
    authenticate,
    getAllUsers,
    register,
    getName,
};


function authenticate(req, res, next) {
    console.log("Authenticate():", req.body);
    userService.authenticate(req.body)
        .then(user => user ? res.json(user) : res.status(400).json({ message: 'Username or password is incorrect' }))
        .catch(err => next(err));
}

function getAllUsers(req, res, next) {
    //  console.log("getAll", req.body);
    userService.getAllUsers()
        .then(
            users => res.json(users))
        .catch(err => next(err));
}

function register(req, res, next) {
    userService.addUser(req.body)
        .then(() => res.json({}))
        .catch(err => next(err));
}




function getName(req, res, next) {
    userService.getName(req.user.sub)
        .then(names => {res.json(names)})
        .catch(err => next(err));
}


